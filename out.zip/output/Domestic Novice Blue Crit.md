# Domestic Novice Blue Crit

|    |   Race Number | Last Name   | First Name   | Team                | Phone          | Emergency Contact   | Emergency Phone   |   USAC License |   ZIP |   USAC Category Road | Category Entered / Merchandise Ordered   |
|---:|--------------:|:------------|:-------------|:--------------------|:---------------|:--------------------|:------------------|---------------:|------:|---------------------:|:-----------------------------------------|
| 29 |          1509 | Ford        | Patrick      | AAVC                | (602) 739-0500 | Julia Ford          | (248) 425-0852    |         308145 | 48104 |                    5 | Domestic Novice Blue Crit                |
| 92 |          1506 | Bae         | Benjamin     | Ann Arbor Velo Club | 7345966105     | Yun Jeong Ahn       | (734) 450-2490    |         645227 | 48105 |                    5 | Domestic Novice Blue Crit                |