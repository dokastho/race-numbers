# Collegiate Women's A Blue Crit

|    | Race Number   | Last Name   | First Name   | Team                               | Phone          | Emergency Contact   | Emergency Phone   |   USAC License |   ZIP |   USAC Category Road | Category Entered / Merchandise Ordered   |
|---:|:--------------|:------------|:-------------|:-----------------------------------|:---------------|:--------------------|:------------------|---------------:|------:|---------------------:|:-----------------------------------------|
| 21 |               | Lucke       | Jenny        | University of Wisconsin Madison    | (303) 746-8567 | Chris Lucke         | (303) 921-6999    |         364444 | 80027 |                    2 | Collegiate Women's A Blue Crit           |
| 76 |               | Callison    | Elizabeth    | University of Michigan - Ann Arbor | (989) 370-1803 | Linda Callison      | (989) 370-6493    |         556875 | 48104 |                    3 | Collegiate Women's A Blue Crit           |