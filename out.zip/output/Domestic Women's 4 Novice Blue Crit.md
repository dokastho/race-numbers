# Domestic Women's 4 Novice Blue Crit

|    |   Race Number | Last Name   | First Name   | Team                  | Phone          | Emergency Contact   | Emergency Phone   |   USAC License |   ZIP |   USAC Category Road | Category Entered / Merchandise Ordered   |
|---:|--------------:|:------------|:-------------|:----------------------|:---------------|:--------------------|:------------------|---------------:|------:|---------------------:|:-----------------------------------------|
| 90 |          1400 | Ginell      | Keara        | Ann Arbor Velo Club   | 6308420563     | Stephan Ginell      | 6302123818        |         644742 | 48105 |                    4 | Domestic Women's 4/Novice Blue Crit      |
| 30 |          1501 | Wolgast     | Jenni        | Ann Arbor Velo Club   | (810) 230-4275 | Roger Berdan        | (586) 204-5683    |         617214 | 48473 |                    5 | Domestic Women's 4/Novice Blue Crit      |
| 39 |          1504 | Lisull      | Emma         | Wolverine Sports Club | (734) 646-3890 | Emma K Lisull       | (734) 646-4993    |         637356 | 48220 |                    5 | Domestic Women's 4/Novice Blue Crit      |