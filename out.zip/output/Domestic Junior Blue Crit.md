# Domestic Junior Blue Crit

|     |   Race Number | Last Name   | First Name   | Team                | Phone          | Emergency Contact   | Emergency Phone   |   USAC License |   ZIP |   USAC Category Road | Category Entered / Merchandise Ordered   |
|----:|--------------:|:------------|:-------------|:--------------------|:---------------|:--------------------|:------------------|---------------:|------:|---------------------:|:-----------------------------------------|
|  38 |          1401 | Serrano     | Cosette      | Ann Arbor Velo Club | (734) 545-9695 | David Serrano       | (734) 545-9695    |         612341 | 48105 |                    4 | Domestic Junior Blue Crit                |
|  31 |          1500 | Wolgast     | Kathryn      | Ann Arbor Velo Club | (810) 919-8686 | Jenni Wolgast       | (810) 230-4275    |         610800 | 48473 |                    5 | Domestic Junior Blue Crit                |
| 131 |          1502 | de Jong     | Amalia       | Ann Arbor Velo Club | (414) 533-5664 | Julie de Jong       | (313) 378-1747    |         563625 | 48197 |                    5 | Domestic Junior Blue Crit                |
|  17 |          1503 | lafferty    | fiona        | Ann Arbor Velo Club | (734) 417-3494 | mik lafferty        | (734) 417-3494    |         565924 | 48108 |                    5 | Domestic Junior Blue Crit                |