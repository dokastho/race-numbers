# Domestic Women's P 1 2 3 4 Blue Crit

|    |   Race Number | Last Name   | First Name   | Team                | Phone          | Emergency Contact   | Emergency Phone   |   USAC License | ZIP        |   USAC Category Road | Category Entered / Merchandise Ordered   |
|---:|--------------:|:------------|:-------------|:--------------------|:---------------|:--------------------|:------------------|---------------:|:-----------|---------------------:|:-----------------------------------------|
| 91 |          1400 | Ginell      | Keara        | Ann Arbor Velo Club | 6308420563     | Stephan Ginell      | 6302123818        |         644742 | 48105      |                    4 | Domestic Women's P/1/2/3/4 Blue Crit     |
| 99 |               | Ruiz        | Valeria      | UChicago Velo Club  | (954) 681-8915 | Clara Argote        | (305) 890-7558    |         653061 | 60637-3434 |                    4 | Domestic Women's P/1/2/3/4 Blue Crit     |